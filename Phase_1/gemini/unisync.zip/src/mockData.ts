import { User, Task, Message, Deadline } from './types';
import { addDays, subDays, format } from 'date-fns';

const today = new Date();

export const users: User[] = [
  { id: 'u1', name: 'Alex Chen', avatar: 'https://i.pravatar.cc/150?u=u1', color: 'bg-blue-500' },
  { id: 'u2', name: 'Sarah Smith', avatar: 'https://i.pravatar.cc/150?u=u2', color: 'bg-emerald-500' },
  { id: 'u3', name: 'Jordan Lee', avatar: 'https://i.pravatar.cc/150?u=u3', color: 'bg-amber-500' },
  { id: 'u4', name: 'Mia Wong', avatar: 'https://i.pravatar.cc/150?u=u4', color: 'bg-purple-500' },
];

export const currentUser = users[0];

export const initialTasks: Task[] = [
  { id: 't1', title: 'Research literature review', assigneeId: 'u1', status: 'done', deadline: format(subDays(today, 2), 'yyyy-MM-dd') },
  { id: 't2', title: 'Draft introduction', assigneeId: 'u2', status: 'in-progress', deadline: format(addDays(today, 1), 'yyyy-MM-dd') },
  { id: 't3', title: 'Create presentation slides', assigneeId: 'u3', status: 'todo', deadline: format(addDays(today, 5), 'yyyy-MM-dd') },
  { id: 't4', title: 'Data analysis', assigneeId: 'u4', status: 'in-progress', deadline: format(addDays(today, 3), 'yyyy-MM-dd') },
  { id: 't5', title: 'Format citations', assigneeId: null, status: 'todo', deadline: format(addDays(today, 7), 'yyyy-MM-dd') },
];

export const initialMessages: Message[] = [
  { id: 'm1', senderId: 'u2', text: 'Hey guys, I started on the intro. Should I include the historical context?', timestamp: new Date(today.getTime() - 1000 * 60 * 60 * 2).toISOString(), topic: 'General' },
  { id: 'm2', senderId: 'u3', text: 'Yes, definitely. Just a brief paragraph should be enough.', timestamp: new Date(today.getTime() - 1000 * 60 * 60 * 1.5).toISOString(), topic: 'General' },
  { id: 'm3', senderId: 'u4', text: 'I am struggling with the dataset. Can someone help me clean it up tomorrow?', timestamp: new Date(today.getTime() - 1000 * 60 * 30).toISOString(), topic: 'Data Analysis' },
  { id: 'm4', senderId: 'u1', text: 'I can help after my morning class!', timestamp: new Date(today.getTime() - 1000 * 60 * 5).toISOString(), topic: 'Data Analysis' },
];

export const deadlines: Deadline[] = [
  { id: 'd1', userId: 'u1', title: 'CS301 Midterm', date: format(addDays(today, 2), 'yyyy-MM-dd'), weight: 3 },
  { id: 'd2', userId: 'u2', title: 'History Essay', date: format(addDays(today, 2), 'yyyy-MM-dd'), weight: 2 },
  { id: 'd3', userId: 'u3', title: 'Math Assignment', date: format(addDays(today, 3), 'yyyy-MM-dd'), weight: 1 },
  { id: 'd4', userId: 'u4', title: 'Biology Lab Report', date: format(addDays(today, 2), 'yyyy-MM-dd'), weight: 3 },
  { id: 'd5', userId: 'u1', title: 'Group Project Draft', date: format(addDays(today, 7), 'yyyy-MM-dd'), weight: 2 },
  { id: 'd6', userId: 'u2', title: 'Group Project Draft', date: format(addDays(today, 7), 'yyyy-MM-dd'), weight: 2 },
  { id: 'd7', userId: 'u3', title: 'Group Project Draft', date: format(addDays(today, 7), 'yyyy-MM-dd'), weight: 2 },
  { id: 'd8', userId: 'u4', title: 'Group Project Draft', date: format(addDays(today, 7), 'yyyy-MM-dd'), weight: 2 },
];
