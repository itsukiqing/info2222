export type User = {
  id: string;
  name: string;
  avatar: string;
  color: string;
};

export type TaskStatus = 'todo' | 'in-progress' | 'done';

export type Task = {
  id: string;
  title: string;
  assigneeId: string | null;
  status: TaskStatus;
  deadline: string;
};

export type Message = {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  topic: string;
};

export type Deadline = {
  id: string;
  userId: string;
  title: string;
  date: string;
  weight: number;
};
