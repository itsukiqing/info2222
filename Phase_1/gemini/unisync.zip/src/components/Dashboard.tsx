import { users, initialTasks } from '../mockData';
import { CheckCircle2, Clock } from 'lucide-react';

export function Dashboard() {
  const completedTasks = initialTasks.filter(t => t.status === 'done').length;
  const totalTasks = initialTasks.length;
  const progress = Math.round((completedTasks / totalTasks) * 100);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header>
        <h2 className="text-3xl font-bold text-slate-900">Project Dashboard</h2>
        <p className="text-slate-500 mt-1">Overview of your group's progress and current tasks.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
          <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-4">Overall Progress</h3>
          <div className="flex items-end gap-4 mb-2">
            <span className="text-4xl font-bold text-slate-900">{progress}%</span>
            <span className="text-sm text-slate-500 mb-1">{completedTasks} of {totalTasks} tasks done</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2.5 mt-auto">
            <div className="bg-indigo-500 h-2.5 rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider">Completed</h3>
            <p className="text-2xl font-bold text-slate-900">{completedTasks} Tasks</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <Clock size={24} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider">In Progress</h3>
            <p className="text-2xl font-bold text-slate-900">{initialTasks.filter(t => t.status === 'in-progress').length} Tasks</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100">
          <h3 className="text-lg font-semibold text-slate-900">Team Members</h3>
        </div>
        <div className="divide-y divide-slate-100">
          {users.map(user => {
            const userTasks = initialTasks.filter(t => t.assigneeId === user.id);
            const activeTask = userTasks.find(t => t.status === 'in-progress');
            
            return (
              <div key={user.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full ring-2 ring-white" />
                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${user.color}`}></div>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-900">{user.name}</h4>
                    <p className="text-sm text-slate-500">
                      {userTasks.length} assigned tasks
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  {activeTask ? (
                    <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-3 py-1.5 rounded-full">
                      <Clock size={14} />
                      <span className="font-medium truncate max-w-[200px]">{activeTask.title}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-sm text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full">
                      <CheckCircle2 size={14} />
                      <span className="font-medium">No active tasks</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
