import { LayoutDashboard, MessageSquare, CheckSquare, CalendarDays } from 'lucide-react';
import { cn } from '../lib/utils';
import { currentUser } from '../mockData';

type SidebarProps = {
  activeTab: string;
  setActiveTab: (tab: string) => void;
};

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'chat', label: 'Group Chat', icon: MessageSquare },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'heatmap', label: 'Stress Heatmap', icon: CalendarDays },
  ];

  return (
    <div className="w-64 bg-slate-900 text-slate-300 flex flex-col h-full border-r border-slate-800">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <span className="bg-indigo-500 text-white p-1.5 rounded-lg">
            <CalendarDays size={20} />
          </span>
          UniSync
        </h1>
      </div>
      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors text-sm font-medium",
                isActive 
                  ? "bg-indigo-500/10 text-indigo-400" 
                  : "hover:bg-slate-800 hover:text-white"
              )}
            >
              <Icon size={18} className={isActive ? "text-indigo-400" : "text-slate-400"} />
              {item.label}
            </button>
          );
        })}
      </nav>
      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 px-2">
          <img src={currentUser.avatar} alt={currentUser.name} className="w-8 h-8 rounded-full ring-2 ring-slate-800" />
          <div className="flex flex-col text-left">
            <span className="text-sm font-medium text-white">{currentUser.name}</span>
            <span className="text-xs text-slate-500">Computer Science</span>
          </div>
        </div>
      </div>
    </div>
  );
}
