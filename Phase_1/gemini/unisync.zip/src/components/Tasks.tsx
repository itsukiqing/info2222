import { useState } from 'react';
import { initialTasks, users } from '../mockData';
import { Task, TaskStatus } from '../types';
import { Plus, Calendar, MoreHorizontal } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

export function Tasks() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);

  const columns: { id: TaskStatus; title: string; color: string }[] = [
    { id: 'todo', title: 'To Do', color: 'bg-slate-100 text-slate-700' },
    { id: 'in-progress', title: 'In Progress', color: 'bg-amber-100 text-amber-800' },
    { id: 'done', title: 'Done', color: 'bg-emerald-100 text-emerald-800' },
  ];

  const moveTask = (taskId: string, newStatus: TaskStatus) => {
    setTasks(tasks.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
  };

  const assignTask = (taskId: string, userId: string) => {
    setTasks(tasks.map(t => t.id === taskId ? { ...t, assigneeId: userId } : t));
  };

  return (
    <div className="p-8 max-w-7xl mx-auto h-full flex flex-col animate-in fade-in duration-500">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Task Assignment</h2>
          <p className="text-slate-500 mt-1">Manage responsibilities and track progress.</p>
        </div>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-full font-medium hover:bg-indigo-700 transition-colors shadow-sm">
          <Plus size={18} />
          New Task
        </button>
      </header>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-hidden">
        {columns.map(col => {
          const columnTasks = tasks.filter(t => t.status === col.id);
          
          return (
            <div key={col.id} className="flex flex-col bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-100/50">
                <div className="flex items-center gap-2">
                  <span className={cn("px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider", col.color)}>
                    {col.title}
                  </span>
                  <span className="text-slate-400 text-sm font-medium">{columnTasks.length}</span>
                </div>
                <button className="text-slate-400 hover:text-slate-600">
                  <MoreHorizontal size={20} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {columnTasks.map(task => {
                  const assignee = users.find(u => u.id === task.assigneeId);
                  
                  return (
                    <div key={task.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow group">
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="font-medium text-slate-900 leading-snug">{task.title}</h4>
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <select 
                            className="text-xs border-slate-200 rounded-md text-slate-600 bg-slate-50 py-1 pl-2 pr-6 focus:ring-indigo-500 focus:border-indigo-500"
                            value={task.status}
                            onChange={(e) => moveTask(task.id, e.target.value as TaskStatus)}
                          >
                            <option value="todo">To Do</option>
                            <option value="in-progress">In Progress</option>
                            <option value="done">Done</option>
                          </select>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
                        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                          <Calendar size={14} />
                          {format(new Date(task.deadline), 'MMM d')}
                        </div>
                        
                        <div className="relative">
                          {assignee ? (
                            <div className="flex items-center gap-2 cursor-pointer" title="Click to reassign">
                              <img src={assignee.avatar} alt={assignee.name} className="w-7 h-7 rounded-full ring-2 ring-white" />
                            </div>
                          ) : (
                            <select 
                              className="text-xs border-dashed border-slate-300 rounded-full text-slate-500 bg-slate-50 py-1 pl-2 pr-6 focus:ring-indigo-500 focus:border-indigo-500 appearance-none"
                              onChange={(e) => assignTask(task.id, e.target.value)}
                              defaultValue=""
                            >
                              <option value="" disabled>Assign</option>
                              {users.map(u => (
                                <option key={u.id} value={u.id}>{u.name}</option>
                              ))}
                            </select>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
