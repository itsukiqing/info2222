import { useState } from 'react';
import { users, deadlines } from '../mockData';
import { format, addDays, isSameDay } from 'date-fns';
import { Calendar as CalendarIcon, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { cn } from '../lib/utils';

export function Heatmap() {
  const today = new Date();
  const [selectedDate, setSelectedDate] = useState<Date | null>(today);

  // Generate next 14 days
  const days = Array.from({ length: 14 }).map((_, i) => addDays(today, i));

  const getStressScore = (date: Date) => {
    const dayDeadlines = deadlines.filter(d => isSameDay(new Date(d.date), date));
    return dayDeadlines.reduce((sum, d) => sum + d.weight, 0);
  };

  const getStressColor = (score: number) => {
    if (score === 0) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (score <= 3) return 'bg-emerald-200 text-emerald-800 border-emerald-300';
    if (score <= 6) return 'bg-amber-200 text-amber-800 border-amber-300';
    return 'bg-red-200 text-red-800 border-red-300';
  };

  const getStressLabel = (score: number) => {
    if (score === 0) return 'Clear';
    if (score <= 3) return 'Low';
    if (score <= 6) return 'Moderate';
    return 'High Stress';
  };

  const selectedDeadlines = selectedDate 
    ? deadlines.filter(d => isSameDay(new Date(d.date), selectedDate))
    : [];

  // Find best meeting days (score 0 or 1)
  const bestMeetingDays = days.filter(d => getStressScore(d) <= 1).slice(0, 3);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="flex items-start justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Deadline Stress Heatmap</h2>
          <p className="text-slate-500 mt-1">Coordinate group work around everyone's individual deadlines.</p>
        </div>
        <div className="flex items-center gap-4 bg-white px-4 py-2 rounded-full border border-slate-200 shadow-sm text-sm">
          <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-400"></div> Low</div>
          <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-amber-400"></div> Moderate</div>
          <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-400"></div> High</div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Calendar Grid */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-2 mb-6">
            <CalendarIcon className="text-indigo-500" />
            <h3 className="text-lg font-semibold text-slate-900">Next 14 Days</h3>
          </div>
          
          <div className="grid grid-cols-7 gap-3">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                {day}
              </div>
            ))}
            
            {/* Empty slots for padding if needed (simplified here to just start from today's day of week) */}
            {Array.from({ length: today.getDay() }).map((_, i) => (
              <div key={`empty-${i}`} className="h-24 rounded-xl border border-dashed border-slate-200 bg-slate-50/50"></div>
            ))}

            {days.map((date, i) => {
              const score = getStressScore(date);
              const isSelected = selectedDate && isSameDay(date, selectedDate);
              
              return (
                <button
                  key={i}
                  onClick={() => setSelectedDate(date)}
                  className={cn(
                    "h-24 rounded-xl border p-2 flex flex-col items-start justify-between transition-all hover:shadow-md",
                    getStressColor(score),
                    isSelected ? "ring-2 ring-indigo-500 ring-offset-2 scale-105 shadow-md" : "opacity-90 hover:opacity-100"
                  )}
                >
                  <span className="font-bold text-sm">{format(date, 'd')}</span>
                  <div className="w-full">
                    {score > 0 && (
                      <div className="flex -space-x-1.5 justify-end">
                        {deadlines.filter(d => isSameDay(new Date(d.date), date)).slice(0, 3).map((d, idx) => {
                          const user = users.find(u => u.id === d.userId);
                          return (
                            <img key={idx} src={user?.avatar} className="w-5 h-5 rounded-full ring-1 ring-white" alt={user?.name} />
                          );
                        })}
                        {deadlines.filter(d => isSameDay(new Date(d.date), date)).length > 3 && (
                          <div className="w-5 h-5 rounded-full bg-slate-800 text-white text-[10px] flex items-center justify-center ring-1 ring-white">
                            +
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Details Panel */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
              {selectedDate ? format(selectedDate, 'EEEE, MMMM d') : 'Select a date'}
            </h3>
            
            {selectedDate && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-sm font-medium text-slate-600">Stress Level</span>
                  <span className={cn(
                    "px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                    getStressColor(getStressScore(selectedDate))
                  )}>
                    {getStressLabel(getStressScore(selectedDate))}
                  </span>
                </div>

                {selectedDeadlines.length > 0 ? (
                  <div className="space-y-3 mt-4">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Deadlines</h4>
                    {selectedDeadlines.map(deadline => {
                      const user = users.find(u => u.id === deadline.userId);
                      return (
                        <div key={deadline.id} className="flex items-start gap-3 p-3 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors">
                          <img src={user?.avatar} alt={user?.name} className="w-8 h-8 rounded-full" />
                          <div>
                            <p className="text-sm font-medium text-slate-900">{deadline.title}</p>
                            <p className="text-xs text-slate-500">{user?.name}</p>
                          </div>
                          <div className="ml-auto">
                            {deadline.weight === 3 && <AlertTriangle size={16} className="text-red-500" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-400 flex flex-col items-center">
                    <CheckCircle2 size={32} className="mb-2 text-emerald-400" />
                    <p className="text-sm">No deadlines on this day!</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
            <h3 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Info size={16} />
              Suggested Meeting Times
            </h3>
            <div className="space-y-2">
              {bestMeetingDays.map((day, i) => (
                <div key={i} className="bg-white p-3 rounded-lg shadow-sm border border-indigo-100 flex items-center justify-between">
                  <span className="font-medium text-indigo-900">{format(day, 'EEEE, MMM d')}</span>
                  <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">Low Stress</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
