import { useState, useRef, useEffect, FormEvent } from 'react';
import { users, currentUser, initialMessages } from '../mockData';
import { Message } from '../types';
import { Send, Hash, Sparkles, X } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

const TOPICS = ['General', 'Data Analysis', 'Presentation', 'Research'];

export function Chat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [activeTopic, setActiveTopic] = useState('General');
  const [inputValue, setInputValue] = useState('');
  const [showCatchUp, setShowCatchUp] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const filteredMessages = messages.filter(m => m.topic === activeTopic);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [filteredMessages]);

  const handleSend = (e: FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: `m${Date.now()}`,
      senderId: currentUser.id,
      text: inputValue,
      timestamp: new Date().toISOString(),
      topic: activeTopic,
    };

    setMessages([...messages, newMessage]);
    setInputValue('');
  };

  return (
    <div className="flex h-full bg-white animate-in fade-in duration-500">
      {/* Topics Sidebar */}
      <div className="w-64 border-r border-slate-100 flex flex-col bg-slate-50/50">
        <div className="p-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-xs">Topics</h3>
        </div>
        <div className="p-2 space-y-1">
          {TOPICS.map(topic => (
            <button
              key={topic}
              onClick={() => setActiveTopic(topic)}
              className={cn(
                "w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                activeTopic === topic 
                  ? "bg-indigo-100 text-indigo-700" 
                  : "text-slate-600 hover:bg-slate-100"
              )}
            >
              <Hash size={16} className={activeTopic === topic ? "text-indigo-500" : "text-slate-400"} />
              {topic}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col relative">
        {/* Chat Header */}
        <div className="h-16 border-b border-slate-100 flex items-center justify-between px-6 bg-white z-10">
          <div className="flex items-center gap-2">
            <Hash size={20} className="text-slate-400" />
            <h2 className="text-lg font-semibold text-slate-900">{activeTopic}</h2>
          </div>
          <button
            onClick={() => setShowCatchUp(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-full text-sm font-medium transition-colors"
          >
            <Sparkles size={16} />
            Catch Me Up
          </button>
        </div>

        {/* Catch Up Banner */}
        {showCatchUp && (
          <div className="absolute top-16 left-0 right-0 bg-indigo-600 text-white p-4 shadow-lg z-20 flex items-start gap-4 animate-in slide-in-from-top-2">
            <div className="bg-white/20 p-2 rounded-full mt-1">
              <Sparkles size={20} className="text-indigo-100" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">AI Summary for {currentUser.name}</h4>
              <p className="text-indigo-100 text-sm leading-relaxed">
                Since you last checked, Sarah started the introduction and asked about historical context. Mia is struggling with the dataset and needs help tomorrow. You offered to help her after your morning class.
              </p>
            </div>
            <button onClick={() => setShowCatchUp(false)} className="text-indigo-200 hover:text-white">
              <X size={20} />
            </button>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30">
          {filteredMessages.map((msg, index) => {
            const sender = users.find(u => u.id === msg.senderId);
            const isMe = msg.senderId === currentUser.id;
            const showHeader = index === 0 || filteredMessages[index - 1].senderId !== msg.senderId;

            return (
              <div key={msg.id} className={cn("flex gap-4 max-w-3xl", isMe ? "ml-auto flex-row-reverse" : "")}>
                {showHeader ? (
                  <img src={sender?.avatar} alt={sender?.name} className="w-10 h-10 rounded-full shadow-sm" />
                ) : (
                  <div className="w-10" /> // Spacer
                )}
                <div className={cn("flex flex-col", isMe ? "items-end" : "items-start")}>
                  {showHeader && (
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-sm font-medium text-slate-900">{sender?.name}</span>
                      <span className="text-xs text-slate-400">{format(new Date(msg.timestamp), 'h:mm a')}</span>
                    </div>
                  )}
                  <div className={cn(
                    "px-4 py-2.5 rounded-2xl text-[15px] leading-relaxed shadow-sm",
                    isMe 
                      ? "bg-indigo-600 text-white rounded-tr-sm" 
                      : "bg-white border border-slate-100 text-slate-800 rounded-tl-sm"
                  )}>
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-slate-100">
          <form onSubmit={handleSend} className="flex items-center gap-2 max-w-4xl mx-auto">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={`Message #${activeTopic}...`}
              className="flex-1 bg-slate-100 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 rounded-full px-6 py-3 text-slate-900 transition-all outline-none"
            />
            <button
              type="submit"
              disabled={!inputValue.trim()}
              className="bg-indigo-600 text-white p-3 rounded-full hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
            >
              <Send size={20} className="ml-1" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
